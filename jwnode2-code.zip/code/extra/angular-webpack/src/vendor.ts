// Angular.
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/core';
import '@angular/common';
import '@angular/http';
import '@angular/router';

// RxJS.
import 'rxjs';

// Bootstrap.
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
